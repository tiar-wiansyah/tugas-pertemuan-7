<?php
$newPass = "admin";
echo password_hash($newPass, PASSWORD_DEFAULT);